export const lideres = [ 

    {
      id: "01",
      codigo:'L001',
      nome: "igor da costa silva",
      area: "AB001",
      telefones: [
        {
            number:'91982785290',
            type:'telefone'
        },
        {
            number:'91982785290',
            type:'whatsapp'
        }
    ],
    endereco:{
        lougadoro:'Passagem Natal',
        casa:24,
        quadra:29,
        bairro:'novo horizonte',
        cidade:'marituba'
    },
    email:'igor@gmail.com',
    img:'C:\\Users\\igord\\Downloads\\coreui-free-react-admin-template-main\\coreui-free-react-admin-template-main\\src\\assets\\images\\avatars\\1.jpg',

    },
    {
        id: "02",
        codigo:'L002',
        nome: "Hugo Bahia Silva",
        area: "AC001",
        telefones: [
          {
              number:'91982785290',
              type:'telefone'
          },
          {
              number:'91982785290',
              type:'whatsapp'
          }
      ],
      endereco:{
        lougadoro:'Passagem Natal',
        casa:24,
        quadra:29,
        bairro:'novo horizonte',
        cidade:'marituba'
    },
      email:'hugo@gmail.com',
      img:'C:\\Users\\igord\\Downloads\\coreui-free-react-admin-template-main\\coreui-free-react-admin-template-main\\src\\assets\\images\\avatars\\2.jpg',
  
      },

      {
        id: "03",
        codigo:'L003',
        nome: "jennefer fernandes silva",
        area: "AB001",
        telefones: [
          {
              number:'91982785290',
              type:'telefone'
          },
          {
              number:'91982785290',
              type:'whatsapp'
          }
      ],
      endereco:{
        lougadoro:'Passagem Natal',
        casa:24,
        quadra:29,
        bairro:'novo horizonte',
        cidade:'marituba'
    },
      email:'jennefer@gmail.com',
      img:'C:\\Users\\igord\\Downloads\\coreui-free-react-admin-template-main\\coreui-free-react-admin-template-main\\src\\assets\\images\\avatars\\3.jpg',
  
      },

  ]