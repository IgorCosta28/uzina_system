export const cidadoes = [
    {
        id: "01",
        codigo:'C001',
        nome: "Manoel Andrade da silva",
        area: "AB001",
        lider:'L001',
        nascimento:'11/11/1968',
        telefones: [
          {
              number:'91982785290',
              type:'telefone'
          },
          {
              number:'91982785290',
              type:'whatsapp'
          }
      ],
      endereco:{
          lougadoro:'Passagem Nova Vida',
          casa:24,
          quadra:29,
          bairro:'novo',
          cidade:'marituba'
      },
      email:'igor@gmail.com',  
      },

      {
        id: "03",
        codigo:'C003',
        nome: "Tatiane Ribeiro Moraes",
        area: "AC001",
        lider:'L000',
        nascimento:'11/12/1991',
        telefones: [
          {
              number:'91982785290',
              type:'telefone'
          },
          {
              number:'91982785290',
              type:'whatsapp'
          }
      ],
      endereco:{
          lougadoro:'Passagem Boa Esperança',
          casa:24,
          quadra:29,
          bairro:'Novo Horizonte',
          cidade:'marituba'
      },
      email:'igor@gmail.com',  
      },
      {
        id: "02",
        codigo:'C002',
        nome: "Tatiane Ribeiro Moraes",
        area: "AC001",
        lider:'L000',
        nascimento:'11/12/1991',
        telefones: [
          {
              number:'91982785290',
              type:'telefone'
          },
          {
              number:'91982785290',
              type:'whatsapp'
          }
      ],
      endereco:{
          lougadoro:'Passagem Boa Esperança',
          casa:24,
          quadra:29,
          bairro:'Novo Horizonte',
          cidade:'marituba'
      },
      email:'igor@gmail.com',  
      }
]