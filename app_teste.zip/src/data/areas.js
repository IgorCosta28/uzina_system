export const areas = [ 

      {
        id: "01",
        area: "Novo Horizonte",
        tipo: "conjunto",
        codigo: "AC001"
      },

      {
        id: "02",
        area: "Uniao",
        tipo: "Bairro",
        codigo: "AB001"
      },
      {
        id: "03",
        area: "Albatroz",
        tipo: "conjunto",
        codigo: "AC002"
      },

      {
        id: "04",
        area: "Albatroz",
        tipo: "conjunto",
        codigo: "AC003"
      },
      {
        id: "05",
        area: "Albatroz",
        tipo: "conjunto",
        codigo: "AC004"
      }


    ]