import React from 'react'

const Settings = () => {
  
  return (
    <>
      <h1>
        Aqui ficara as configuracao do usuario
      </h1>
    </>
  )
}

export default Settings
