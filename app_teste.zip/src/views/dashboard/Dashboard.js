import { CCol } from '@coreui/react'
import React from 'react'

const Dashboard = () => {
 
  return (
    <>
      <CCol>
        <h1> Aqui ficara alguns dados</h1>
      </CCol>
    </>
  )
}

export default Dashboard
