import React from 'react'

const Consultas = () => {
  return (
    <>

    </>
  )
}

export default Consultas
